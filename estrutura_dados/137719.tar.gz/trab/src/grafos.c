#include <stdio.h>
#include "grafos.h"

int printa(char frase[100])
{
	printf("%s",frase);
}
