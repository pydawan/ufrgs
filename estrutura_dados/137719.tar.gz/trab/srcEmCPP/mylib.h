#define _GNU_SOURCE // necessário porque getline() é extensão GNU

int LeLinhaArquivo(char arquivo[]);
int LePalavraArquivo(char arquivo[]);
