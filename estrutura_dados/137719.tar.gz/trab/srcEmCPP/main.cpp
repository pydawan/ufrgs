
#include "main.h"
#include "grafos.h"
#include "arvores.h"
#include "mylib.h"

int main()
{

	char frase[255];

	LePalavraArquivo("../txt/137719texto1.txt");
	//LeLinhaArquivo("../txt/br.dic");
	//PrintaASC();	

	return 0;
}
