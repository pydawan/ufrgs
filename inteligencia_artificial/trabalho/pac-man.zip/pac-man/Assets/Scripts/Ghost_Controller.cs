using UnityEngine;
using System.Collections;

/// <summary>
/// Classe que controla os movimentos dos fantasmas.
/// </summary>
public class Ghost_Controller : MonoBehaviour {	
	
	//Raycast eh o objeto utilizado na deteccao de colisoes no cenario
	private RaycastHit hit;
	
	//distancia padrao da checagem do raycast para bloqueios nos eixos x e z
	public float rayBlockedDistX = 0.3f;
	public float rayBlockedDistY = 0.3f;
	
	//indice da camada do terreno
	private int groundMask = 8;
	
	//tempo esperado ateh o proximo update. Padrao = 1s
	public float update = 1;
	
	//velocidade na qual o fantasma se move.
	public float speed = 10;
	
	//momento do proximo update
	float nextUpdate;
	
	//vetor com as direcoes em que o fantasma sera movido
	Vector3 moveDirection;
	
	/// <summary>
    /// Chamada na inicializacao da classe pelo unity atraves da classe MonoBehaviour. 
    /// Inicia a instancia dessa classe.
    /// </summary>
	void Start(){
		
		//ignore a fisica de colisao da camada groundMask. Essa eh a camada
		//onde estao os fantasmas. Fazendo isso os fantasmas nao colidem uns com
		//os outros nem com pacman. Ainda sao detectados quando se bate neles mas
		//podem atravessar uns aos outros
        Physics.IgnoreLayerCollision(groundMask, groundMask, true);
		Physics.IgnoreLayerCollision(groundMask, groundMask, true);

	}
	
	/// <summary>
    /// Faz o update da classe. A Unity chama update uma vez por frame a
    /// partir da classe (pai) MonoBehaviour
    /// </summary>
	void Update(){
		
		//se jah eh tempo do proximo update
		if (Time.time > nextUpdate) {
			
			//escolha uma direcao
			ChooseDirection();
				
	    	//atualiza o momento do proximo update como um valor aleatorio 
			//entre 0 e 1 mulitplicado pelo tempo maximo (padrao 1)
	        nextUpdate = Time.time + (Random.value * update);
	        
	    }
		
		//recupere o componente CharacterController ao qual esta classe esta
		//vinculada
		CharacterController controller = GetComponent<CharacterController>();
		
		//mova o personagem na direcao escolhida em relacao ao tempo da
		//atualizacao do ultimo frame
		controller.Move(moveDirection * Time.deltaTime);
	}
	
	/// <summary>
	/// Escolhe uma direcao para o movimento do fantasma.
	/// </summary>
	void ChooseDirection(){
		
		
		
		//faca
		do{
			//Random.onUnitSphere retorna um ponto do plano com um raio 1
	        moveDirection = Random.onUnitSphere;
			
	        //o plano esta deitado sobre o eixo y, mantenha-o em zero
	        moveDirection.y = 0;
		}
		//enquanto o fantasma estiver parado
		while (moveDirection.x == 0 && moveDirection.z == 0);
			
		//se o fantasma for se mover na diagonal
		if(moveDirection.x != 0 && moveDirection.z != 0){
		
			//garanta o movinento em uma unica direcao 
			//zerando um dos outros valores
			//escolha um valor aleatorio entre 1 e 0.
			//se o valor eh maior que 0.5
			if(Random.value > .5f){
				
				//zere o eixo x
				moveDirection.x = 0;
			}
			//senao
			else{
				//zere o eixo z
				moveDirection.z = 0;
			}

		}
		//normaliza o vetor deixando seu comprimento 
		//em 1 no maximo
        moveDirection.Normalize();
		
		//multiplica a direcao pela velocidade
        moveDirection *= speed;
		
	}
}
