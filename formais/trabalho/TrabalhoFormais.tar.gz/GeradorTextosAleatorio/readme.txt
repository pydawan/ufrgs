#use:
python GeradorTextosAleatorio.py gramaticafutebol.txt

estrutura de dados
lista(regras)
regra = obj(string esq,string dir,float prob)
producao =obj(string variavel, listaregra(onde esq=variavel))


a 0.2 *10000
b 0.6 *10000
c 0.2 *10000
n = randomico(10000)
a vai ser escolhido se n <=2000
b vai ser escolhido se n<=8000
c vai ser escolhido se n<=10000
ai garanto q testarei ordenadamente

