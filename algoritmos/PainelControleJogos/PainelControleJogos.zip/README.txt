﻿Este programa foi trabalho de conclusão para cadeira de Algoritmos de Programação.

Local:		UFRGS
Cadeira:	Algoritmos de Programação
Semestre:	2008/2
Professora:	Cora Pinto
Alunos:		Germano Andersson
		Leonardo Ramos




É necessário que já existam, mesmo que em branco os arquivos jogadores.dat, jogos.dat, ranking.txt