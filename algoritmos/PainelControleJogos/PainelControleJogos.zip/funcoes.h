//Prototipos de Funcoes
void CadastraJogador(); //ok
void ConsultaJogador(); //ok
void AlteraJogador(); //ok
void CadastraJogo();
void ConsultaJogo();
void Login();
void Jogar();
void AtualizarDados();
void MenuPrincipal();
void MenuLogin();
void MenuJogadores();
void MenuJogos();
void MenuRanking();
void ConsultaRanking(FILE *rank, char nome_arq[50]); //ok
void MenuJogar();

// Funcoes para jogadores
void ConsultaJogador()
{
	JOGADOR jogador;
	int procurado=3, encontrado = 0;
	char busca[100];
	
    system ("cls");
	do
	{
	 printf ("1 Busca por id\n2 Busca por nome\n3 Mostra todos\n ");
	 fflush(stdin);
	 scanf ("%d", &procurado);
    } while (procurado != 1 && procurado != 2 && procurado != 3);
    
    if ((arq_jogadores = fopen("jogadores.dat","r")) == NULL)
    {
     printf ("Erro ao abrir o arquivo de jogadores.");
    }
    else
    {   
	 if(procurado != 3)
	 {
     printf ("Digite o valor a buscar: ");
	 fflush(stdin);
     scanf ("%s", busca);
     }
     do
 	 {
        if (procurado == 1) // busca por id
  	    {
           fread(&jogador,sizeof(JOGADOR),1,arq_jogadores);
		   if (!feof(arq_jogadores)) // para nao repetir 2 vezes
		   {
             if (jogador.id == atoi(busca))
			 {
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s", jogador.nome);
				//printf ("Senha: %s", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Jogador Ativo: %c\n", jogador.ativo);
                encontrado = 1;
			 }
           }
    	}
    	else if (procurado == 2) // busca por nome
  	    {
           fread(&jogador,sizeof(JOGADOR),1,arq_jogadores);
		   if (!feof(arq_jogadores)) // para nao repetir 2 vezes
		   {
             if (!(strcmp(jogador.nome,busca)))
			 {
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				//printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Numero Jogadas: %c\n", jogador.ativo);
                encontrado = 1;
			 }
           }
    	}
    	else if (procurado == 3) // mostra todos
  	    {
           fread(&jogador,sizeof(JOGADOR),1,arq_jogadores);
		   if (!feof(arq_jogadores)) // para nao repetir 2 vezes
		   {
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				//printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Numero Jogadas: %c\n", jogador.ativo);
                printf ("-------------------------");
                system("pause");
                encontrado = 1;
           }
    	}
    	
	 } while (!feof(arq_jogadores));
	 if (!encontrado)
		printf ("Jogador nao encontrado.\n");
     fclose(arq_jogadores);
    }  
}

void CadastraJogador()
{
    int i, nomeok=0, senhaok=0, cont;
    char op;
    JOGADOR NovoJogador, BuscaJogador; 
    system("cls");
    
    do // grande laco
    {
        
	// Id
	NovoJogador.id = 0;
	if ((arq_jogadores = fopen("jogadores.dat","rb")) == NULL)
	    printf ("Falha ao abrir arquivo.\n");
    else
    {
	while (!feof(arq_jogadores))
 	{
		fread(&NovoJogador,sizeof(JOGADOR),1,arq_jogadores);
		
	}
	fclose(arq_jogadores);
	NovoJogador.id = NovoJogador.id + 1;
	printf ("Novo jogador tera id: %d\n", NovoJogador.id);
    }	
	// Nome
    do
    {
    printf ("Digite um nome para o jogador: ");
    fflush(stdin);
    fgets(NovoJogador.nome,sizeof(NovoJogador.nome),stdin);
    for (cont = 0; cont < strlen(NovoJogador.nome); cont++) // troca \n por \0
        if (NovoJogador.nome[cont] == '\n')
            NovoJogador.nome[cont] = '\0';
    
    if (strlen(NovoJogador.nome) > MAXNOMEJOGADOR)
        printf("Nome muito comprido.\n");
    else if (strlen(NovoJogador.nome) == 0)
        printf("Nome nao foi digitado.\n");
    else
    {    
        if ((arq_jogadores = fopen("jogadores.dat","rb")) == NULL)
	        printf ("Falha ao abrir arquivo.\n");
        else
        { 
        while (!feof(arq_jogadores))
 	    {
		fread(&BuscaJogador,sizeof(JOGADOR),1,arq_jogadores);
		if (!(BuscaJogador.nome == NovoJogador.nome))
         nomeok = 1;
        else
        {
         printf ("Nome j� existe.");
         nomeok = 0;
         }
	    }
	    fclose(arq_jogadores);
        }
    }
    } while (nomeok == 0); //consiste nome
    
	// Senha
    do
    {
    printf ("Digite a senha para este jogador: ");
    fflush(stdin);
    fgets(NovoJogador.senha,sizeof(NovoJogador.senha),stdin);
    for (cont = 0; cont < strlen(NovoJogador.senha); cont++) // troca \n por \0
        if (NovoJogador.senha[cont] == '\n')
            NovoJogador.senha[cont] = '\0';
    
    if (strlen(NovoJogador.senha) > MAXSENHAJOGADOR)
        printf("Senha muita comprido.\n");
    else if (strlen(NovoJogador.senha) == 0)
        printf("Senha nao foi digitada.\n");
    else
        senhaok = 1;
    } while (senhaok == 0); //consiste senha
	
	// nunca jogou
	NovoJogador.jogadas = 0;
	NovoJogador.ultimo_reg_res = -1;
    NovoJogador.ativo = 's';
    	
    // Salvando no arquivo
	arq_jogadores = fopen("jogadores.dat","a+b");
    if (!arq_jogadores)
        printf ("Erro ao abrir arquivo.");
    else // grava no arquivo
        fwrite(&NovoJogador,sizeof(JOGADOR),1,arq_jogadores);
	fclose(arq_jogadores);
    
    do
    {
    printf ("Voc� deseja cadastrar outro jogador? S | N: ");
    scanf ("%c", &op);
    } while (tolower(op) != 'n' && tolower(op) != 's');
    
    } while ( tolower(op) == 's' ); // fim do grande laco
    
}

void AlteraJogador()
{
	JOGADOR jogador;
	int procurado, encontrado = 0, alterado, cont, jaalterado=0;
	char busca[100], op;
	
    system ("cls");
	do
	{
	 printf ("Vamos buscar o jogador a ser alterado:\n");
     printf ("1- Busca por id\n2- Busca por nome\n ");
	 fflush(stdin);
	 scanf ("%d", &procurado);
    } while (procurado != 1 && procurado != 2);
    
    if ((arq_jogadores = fopen("jogadores.dat","r+b")) == NULL)
    {
     printf ("Erro ao abrir o arquivo de jogadores.");
    }
    else
    {   
	 printf ("Digite o valor a buscar: ");
	 fflush(stdin);
     scanf ("%s", busca);
     
     do
 	 {
        if (procurado == 1) // busca por id
  	    {
           fread(&jogador,sizeof(JOGADOR),1,arq_jogadores);
		   if (!feof(arq_jogadores)) // para nao repetir 2 vezes
		   {
             if (jogador.id == atoi(busca))
			 {
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Jogador Ativo: %c\n", jogador.ativo);
                encontrado = 1;
                fseek(arq_jogadores,-sizeof(JOGADOR),SEEK_CUR); // volta uma estrutura no arquivo
                
                do
                {
	            printf ("\nEste foi o jogador encontrado. Vamos alterar:\n1- Nome\n2- Senha\n3- Status\n"); 
	            fflush(stdin);
	            scanf ("%d", &alterado);
                } while (alterado != 1 && alterado != 2 && alterado != 3);
                switch(alterado)
                {
                                case 1: printf ("-------------------------\n");
                                        printf("Digite o novo nome: ");
                                        fflush(stdin);
                                        fgets(jogador.nome,sizeof(jogador.nome),stdin);
                                        for (cont = 0; cont < strlen(jogador.nome); cont++) // troca \n por \0
                                                if (jogador.nome[cont] == '\n')
                                                              jogador.nome[cont] = '\0';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                                case 2: printf ("-------------------------\n");
                                        printf("Digite a nova senha: ");
                                        fflush(stdin);
                                        fgets(jogador.senha,sizeof(jogador.senha),stdin);
                                        for (cont = 0; cont < strlen(jogador.senha); cont++) // troca \n por \0
                                                if (jogador.senha[cont] == '\n')
                                                            jogador.senha[cont] = '\0';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                                case 3: do
                                        {
                                        printf ("-------------------------\n");
                                        printf("1- Ativado\n2- Desativado\n");
                                        scanf ("%d",&op);
                                        } while (op != 1 && op != 2);
                                        if (op == 1)
                                           jogador.ativo = 's';
                                        else
                                            jogador.ativo = 'n';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                }
                system ("cls");
                printf ("Jogador alterado:\n");
                fseek(arq_jogadores,-sizeof(JOGADOR),SEEK_CUR); // volta uma estrutura no arquivo
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Status Jogador: %c\n", jogador.ativo);
				jaalterado=1;
			 }
           }
    	}
    	else if (procurado == 2) // busca por nome
  	    {
           
           fread(&jogador,sizeof(JOGADOR),1,arq_jogadores);
		   if (!feof(arq_jogadores)) // para nao repetir 2 vezes
		   {
             if (!(strcmp(jogador.nome,busca)))
			 {
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Status Jogador: %c\n", jogador.ativo);
                encontrado = 1;
                fseek(arq_jogadores,-sizeof(JOGADOR),SEEK_CUR); // volta uma estrutura no arquivo
                
                do
                {
	            printf ("\nEste foi o jogador encontrado. Vamos alterar:\n1- Nome\n2- Senha\n3- Status\n"); 
	            fflush(stdin);
	            scanf ("%d", &alterado);
                } while (alterado != 1 && alterado != 2 && alterado != 3);
                switch(alterado)
                {
                                case 1: printf ("-------------------------\n");
                                        printf("Digite o novo nome: ");
                                        fflush(stdin);
                                        fgets(jogador.nome,sizeof(jogador.nome),stdin);
                                        for (cont = 0; cont < strlen(jogador.nome); cont++) // troca \n por \0
                                                if (jogador.nome[cont] == '\n')
                                                              jogador.nome[cont] = '\0';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                                case 2: printf ("-------------------------\n");
                                        printf("Digite a nova senha: ");
                                        fflush(stdin);
                                        fgets(jogador.senha,sizeof(jogador.senha),stdin);
                                        for (cont = 0; cont < strlen(jogador.senha); cont++) // troca \n por \0
                                                if (jogador.senha[cont] == '\n')
                                                            jogador.senha[cont] = '\0';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                                case 3: do
                                        {
                                        printf ("-------------------------\n");
                                        printf("1- Ativado\n2- Desativado\n");
                                        scanf ("%d",&op);
                                        } while (op != 1 && op != 2);
                                        if (op == 1)
                                           jogador.ativo = 's';
                                        else
                                            jogador.ativo = 'n';
                                        fwrite(&jogador,sizeof(JOGADOR),1,arq_jogadores);
                                        break;
                }
                system ("cls");
                printf ("Jogador alterado:\n");
                fseek(arq_jogadores,-sizeof(JOGADOR),SEEK_CUR); // volta uma estrutura no arquivo
                printf ("\nID: %d\n", jogador.id);
                printf ("Nome: %s\n", jogador.nome);
				printf ("Senha: %s\n", jogador.senha);
				printf ("Numero Jogadas: %d\n", jogador.jogadas);
				printf ("Status Jogador: %c\n", jogador.ativo);
				jaalterado=1;
             }
           }
     
        }
	 } while ((!feof(arq_jogadores)) && (jaalterado == 0));
	 if (!encontrado)
		printf ("Jogador nao encontrado.\n");
     fclose(arq_jogadores);
    }  
}




void MenuJogos()
{
int cont=0;
    char tab;
    do
    {
         system("color f2");
         gotoxy(1,1);
         textbackground(GREEN);
         textcolor(BLACK);
         textbackground(WHITE); 
        
         if(cont == 0) 
         textbackground(GREEN);
         printf("1-Inclui novo jogo");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 1) 
         textbackground(GREEN);
         printf("2-Consulta jogos cadastrados");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 2) 
         textbackground(GREEN);
         printf("3-Consulta jogo");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 3) 
         textbackground(GREEN);
         printf("4-Retorna");
         textbackground(WHITE); 
         printf("\n");
         
         do
         {
                   fflush(stdin);
                   tab = getch();
         } while(!(tab==9 || tab==10 || tab==13));
         cont++;
         if(cont == 4) 
         cont=0;
      }
      while(tab==9);          
      system("cls");
      cont=cont - 1;
      switch(cont)
      {
                 case 0: printf("em desenvolvimento\n");
                         break;
                 
                 case 1: printf("em desenvolvimento\n");
                         break;
                 case 2: printf("em desenvolvimento\n");
                         break;
                 case 3: printf("em desenvolvimento\n");
                         break;
                 default:printf("em desenvolvimento\n");//como retornar??   
                         
      
      
      }
}


void MenuJogadores()
{
    int cont=0;
    char tab;
    do
    {
         system("color f2");
         gotoxy(1,1);
         textbackground(GREEN);
         textcolor(BLACK);
         textbackground(WHITE); 
        
         if(cont == 0) 
         textbackground(GREEN);
         printf("1-Inclui novo jogador");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 1) 
         textbackground(GREEN);
         printf("2-Consulta lista de jogadores cadastrados");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 2) 
         textbackground(GREEN);
         printf("3-Consulta jogador por nome ");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 3) 
         textbackground(GREEN);
         printf("4-Consulta resultados do jogador");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 4) 
         textbackground(GREEN);
         printf("5-Exclui jogador");
         textbackground(WHITE); 
         printf("\n"); 
         
         if(cont == 5) 
         textbackground(GREEN);
         printf("6-Retorna");
         textbackground(WHITE); 
         printf("\n"); 
      


         
         do
         {
                   fflush(stdin);
                   tab = getch();
         }
         while(!(tab==9 || tab==10 || tab==13));
         cont++;
         if(cont == 6) 
         cont=0;
      
      }
      while(tab==9);          
      system("cls");
      cont=cont - 1;
      switch(cont)
      {
                 case 0: printf("em desenvolvimento\n");
                         break;
                 
                 case 1: printf("em desenvolvimento\n");
                         break;
                 case 2: printf("em desenvolvimento\n");
                         break;
                 case 3: printf("em desenvolvimento\n");
                         break;
                 case 4: printf("em desenvolvimento\n");
                         break;
                 case 5: printf("em desenvolvimento\n");
                         break;
                 case 6: printf ("oi");
                         MenuPrincipal("Fazer login", 4, LIGHTGRAY);
                         break;
      }
}


void MenuPrincipal(char nome[20], int opcao, int cor)//escolhe entre fazer login(ou logout) e  inclui(ou nao) a opcao "jogar"
{ 

    int cont=0;
    char tab;
    do
    {
         system("color f2");
         gotoxy(1,1);
         textbackground(GREEN);
         textcolor(BLACK);
         textbackground(WHITE); 
        
         if(cont == 0) 
         textbackground(GREEN);
         printf("1-%s", nome);
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 1) 
         textbackground(GREEN);
         printf("2-Incluir/consultar/remover jogadores");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 2) 
         textbackground(GREEN);
         printf("3-Incluir/consultar jogos");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 3) 
         textbackground(GREEN);
         printf("4-Ranking");
         textbackground(WHITE); 
         printf("\n");
         
         if(cont == 4) 
         textbackground(GREEN);
         textcolor(cor);
         printf("5-Jogar");
         textbackground(WHITE); 
         printf("\n"); 
         
         do
         {
                   fflush(stdin);
                   tab = getch();
         }
         while(!(tab==9 || tab==10 || tab==13));
         cont++;
         if(cont == opcao) 
         cont=0;
      
      }
      while(tab==9);          
      system("cls");
      cont=cont - 1;
      switch(cont)
      {
                 case 0: if(! (strcmp(nome, "Fazer logout")))                    //compara nome cm fazer logout
                              MenuPrincipal("Fazer login", 4, LIGHTGRAY);
                         else
                              MenuPrincipal("Fazer logout", 5, BLACK);
                         break;
                 
                 case 1: MenuJogadores();
                         break;
                 
                 case 2: MenuJogos();
                         break;
                 
                 case 3: printf("RANKING em desenvolvimento\n");//erro qndo chama antes d fazer login
                         break;
                         
                 default: printf("menu jogar em desenvolvimento \n");
     }
}



void ConsultaRanking(FILE *rank, char nome_arq[50])
{
     char carac;
     int i=0;
     if((rank = fopen(nome_arq, "r"))==NULL)
             printf("erro de abertura do arquivo ranking.txt\n");
     else
     {
         carac=getc(rank);
         while(!(feof(rank)))
          {
                
                if (carac == '#')
                {
                printf("\nJogo: ");
                carac=getc(rank);
                do
                {
                  printf("%c", carac);
                  carac=getc(rank);
                }while((carac != '@') && (carac != '\n') && (!(feof(rank)))); 
                }
                else if (carac == '@')
                {
                printf("\n\tPontuacao: ");
                carac=getc(rank);
                do
                {
                  printf("%c", carac); 
                   carac=getc(rank);
                }while((carac != '&') && (carac != '\n')&& (!(feof(rank))));
                }
                else if(carac == '&')
                {
                printf("\n\t\tJogador(es): ");
                carac=getc(rank);
                do
                {
                if (carac != '&')
                  printf("%c", carac); 
                carac=getc(rank);
                }while((carac != '@') && (carac != '\n')&& (!(feof(rank))));
                }
                else
                  carac=getc(rank);
         
         
         }
         
       fclose(rank);
     }  
         
             
}
