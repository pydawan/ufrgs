#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio2.h>
#include <string.h>


// Nossas bibliotecas
#include <e:\PainelControleJogos\constantes.h>
#include <e:\PainelControleJogos\estruturas.h>
#include <e:\PainelControleJogos\funcoes.h>



int main()
{
	MenuPrincipal("Fazer login", 4, LIGHTGRAY);
    //MenuPrincipal();
	//CadastraJogador();
	//ConsultaJogador();
	//AlteraJogador();
    //ConsultaRanking(arq_rank, "ranking.txt");
    system ("pause>NULL");
	return 0;
}
